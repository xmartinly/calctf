使用z-match公式计算厚度与速率
